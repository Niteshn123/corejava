package Array;

public class ArrayTableFormat {

	public static void main(String[] args) {
		int i;
		int j=2;
		for(i=1;i<=10; i++)
		{
			int n = i*j;
			System.out.println(j+"*"+i +"="+n);
		}
			

	}

}
