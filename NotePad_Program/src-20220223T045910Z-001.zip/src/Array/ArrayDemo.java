package Array;

public class ArrayDemo {

	public static void main(String[] args) {
		
		//int i = {2,4,5,4,4,};
		int [] i = new int [2];
	i[0] = 2;
		i [1] = 3;
		
		for(int j=0; j<i.length; j++)
			System.out.print(i[j]+" ");
	}

}
