package Switch;

public class SwitchDemo {

	public static void main(String[] args) {
		
		int n=20;
		
		switch(n)
		{
			case 1: System.out.println("10");
			break;
		
		
		case 20: System.out.println("20");
		break;
	
		
		case 3: System.out.println("30");
		break;
	     
		default : System.out.println("Not in 10,20 or 30");
		

	}

}
}
