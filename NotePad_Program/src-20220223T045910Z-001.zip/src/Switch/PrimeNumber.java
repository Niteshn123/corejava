package Switch;

public class PrimeNumber {

	public static void main(String[] args) {
		

	}

}
