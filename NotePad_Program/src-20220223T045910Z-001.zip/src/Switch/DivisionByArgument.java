package Switch;

public class DivisionByArgument {

	public static void main(String[] args) {
		

	}

}
