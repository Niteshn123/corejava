package DateAndTime;

import java.util.Date;

public class FormatDate {

	public static void main(String[] args)
	{
		
		Date d = new Date();
		System.out.println(d);

	}

}
