package ArgumentPassing;

public class ArguementIfElse {

	public static void main(String[] args) {
		
		if(args.length == 5)
		{
			System.out.println("Hello "+ args[2] );
			
		}else
		{
			System.out.println("P");
		}

	}

}
