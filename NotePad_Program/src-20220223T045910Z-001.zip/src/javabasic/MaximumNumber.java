package javabasic;

public class MaximumNumber {

	public static void main(String[] args) {
		int i = 20;
				

	}

}
