package javabasic;

public class AddAllNumberTillGivenNumber
{

	public static void main(String[] args) {
		int i;
		int a=1;
		 
		
		{
			for(i=0; i<=10; i++)
			{
					
		
		a=i+a-1;
		 
			
				
		
         System.out.println(a);
		}
		
	}

}
}
