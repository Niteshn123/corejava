package javabasic;

public class Nestedifelse {

	public static void main(String[] args) {
		int i =1;
		n

	}

}
