package javabasic;

public class ForLoop {
 
	public static void main(String[] args) {
		int i=1;
		for( i =0; i<=5; i++); {
		
		System.out.println(i );

	}

}
}
