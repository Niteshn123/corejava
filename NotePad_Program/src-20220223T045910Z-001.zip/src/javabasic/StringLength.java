package javabasic;

public class StringLength {

	public static void main(String[] args) {
		String s = "Nitesh";
		System.out.println(s.length());

	}

}
