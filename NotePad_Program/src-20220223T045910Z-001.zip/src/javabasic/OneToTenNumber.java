package javabasic;

public class OneToTenNumber {

	public static void main(String[] args) {
		

	}

}
