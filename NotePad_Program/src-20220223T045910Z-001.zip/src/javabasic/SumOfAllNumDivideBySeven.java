package javabasic;

public class SumOfAllNumDivideBySeven {

	public static void main(String[] args) {
		
		int i;
		int n=0;
		int j=0;
		for(i=100; i<=200; i++)
		{
			
			if(i%7==0)
			{
				j=j+1;
				System.out.println(j);
			
			
				
				n=i+n;
			System.out.println(i);
			
		}
			
			
		}

		System.out.println(n);

		
		
	
		

	}
}


