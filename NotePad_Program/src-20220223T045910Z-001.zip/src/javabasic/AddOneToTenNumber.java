package javabasic;

public class AddOneToTenNumber {

	public static void main(String[] args) {
		
		int c=0;
		int i;
		for( i=0; i<=10; i++)
		{
			c=c+i;
					

	}
       System.out.println(c);
}
}
