package javabasic;

public class IfProgram {

	public static void main(String[] args) {
		int n = 10;
		if(n%2 ==0)
		{
			System.out.println("I am even number");
		}

	}

}
