package javabasic;

public class ForEachLoop {

	public static void main(String[] args) {
	 
		int i;
		int [] a = new int[3];
           a[0] = 2;
           a[1] = 4;
           a[2] = 6;
           for( i=0; i<a.length; i++)
        	   
           {
        	   System.out.println (a[i]);
           }
	}

}
