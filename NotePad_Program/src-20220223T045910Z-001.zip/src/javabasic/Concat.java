package javabasic;

public class Concat {

	public static void main(String[] args) {
		String s = "Niteshvv";
		System.out.println(s.concat("v"));
		System.out.println(s.replace("v","k"));
		 
	}

}
