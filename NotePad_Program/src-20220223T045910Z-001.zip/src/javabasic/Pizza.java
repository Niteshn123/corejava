package javabasic;

public class Pizza {
	
	
	

}
