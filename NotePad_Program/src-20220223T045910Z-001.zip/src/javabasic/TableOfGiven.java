package javabasic;



public class TableOfGiven {

public static void main(String[] args) {
	int i=0;
    int n=2;
    int j=0;
   
    		
for(i=0; i<=10; i++)
{ 
	j=n*i;

  System.out.println(j);
	}

}
}
