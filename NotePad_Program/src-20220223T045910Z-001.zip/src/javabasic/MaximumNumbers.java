package javabasic;

public class MaximumNumbers {

	public static void main(String[] args) {
		int i = 40;
		int j = 20;
		if(i>j)
		{
			System.out.println("MaximumNumber" + i);
		}

	}

}
