package javabasic;

public class LocalGlobal {

	public static void main(String[] args) {
		int j = 6;
		int i = 5;
		System.out.println(i);
		System.out.println(j);
		
		for (int k = 0; k < args.length; k++) {
			String string = args[k];
			int h=9;
			
		}

	}

}
