package javabasic;

public class OddNumber {

	public static void main(String[] args) {
	
	int i = 7;
	
	if(i%2==0)
		
	{
		System.out.println("Given number is  not Odd Number =" + i);
	}
		else {
			System.out.println("Given number is  Odd Number =" + i);
		}
			
	}

		
	
	}
8
