package javabasic;

public class DoWhileLoop {

	public static void main(String[] args) {
		int i=0;
		do
		{
			System.out.println("Nitesh" + i);
			i++;
		}while(i<=7);
		  }

		}

	


