package javabasic;

public class TriangleTwo {
	
	public static void main(String[] args) {
		
		int i;
		int j;
		
		for(i=1; i<=5; i++) {
			
			for(j=1; j<=i; j++) {
				System.out.print(j +" ");
			}
			System.out.print("\n");
		}
		
		
	}
	

}
