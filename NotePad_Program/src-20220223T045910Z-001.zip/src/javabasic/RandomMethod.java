package javabasic;

public class RandomMethod {

	public static void main(String[] args) {
		
		
		for( int b = 0; b<=5; b++){
			int i = (int)(Math.random()*100);
			
		System.out.println(i);
		
		
		}
	}

	}


