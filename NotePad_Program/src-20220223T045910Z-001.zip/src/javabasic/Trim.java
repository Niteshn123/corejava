package javabasic;

public class Trim {

	public static void main(String[] args) {
		String s = "Niteshvv ";
		 System.out.println(s+ "vishvkarma");
        System.out.println(s.trim()+"vishvkarma");
	}


	}


