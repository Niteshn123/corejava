package javabasic;

public class AddOfN {

	public static void main(String[] args) {
		int i;
		int sum=0;
		
		for(i=0; i<=12; i++)
			
			sum=sum+i;
		System.out.println(sum);
		
		

	}
	 

}
