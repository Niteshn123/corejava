package javabasic;

public class UseOfTernaryOperator {

	public static void main(String[] args) {
		
		int num = 5;
		String evenOdd = (num%2 ==0)?"Even" : "Odd";
		System.out.println(evenOdd);
		

	}

}
