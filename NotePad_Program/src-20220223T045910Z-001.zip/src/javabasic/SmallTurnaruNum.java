package javabasic;

public class SmallTurnaruNum{

	public static void main(String[] args) {
		
		int i = 3;
		int j = 4;
		String Small = (i<j)?"i is smaller than j" : "i is not smaller" ;
		System.out.println(Small);

	}

}
