package javabasic;

public class Factorial {

	public static void main(String[] args) {
		int c=1;
		int i;
		for(i=4; i>0; i--)
		{
		
			c=c*i;
	
		}
	{
		  System.out.println("Factorial ="+c);
	}

	}
}


